<?php

namespace TrustedLogin\Vendor;

class AuditLog
{


	public function insert($secret_id, $message, $success)
	{
	}
}
